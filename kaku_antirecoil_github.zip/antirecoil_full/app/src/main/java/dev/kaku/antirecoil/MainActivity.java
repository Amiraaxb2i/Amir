package dev.kaku.antirecoil;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity {

    private static TextView tvStatus;
    private SeekBar sbPullDown, sbSpeed, sbFireX, sbFireY;
    private TextView tvPullDown, tvSpeed, tvFireX, tvFireY;
    private Button btnToggle, btnAccessibility;
    private boolean running = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(40, 60, 40, 40);
        root.setBackgroundColor(Color.parseColor("#0D0D0D"));
        scroll.addView(root);
        setContentView(scroll);

        // عنوان
        TextView title = new TextView(this);
        title.setText("KAKU AntiRecoil");
        title.setTextSize(26f);
        title.setTextColor(Color.parseColor("#00FF88"));
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        addSpace(root, 8);

        // وضعیت
        tvStatus = new TextView(this);
        tvStatus.setText("سرویس غیرفعال");
        tvStatus.setTextSize(14f);
        tvStatus.setTextColor(Color.parseColor("#AAAAAA"));
        tvStatus.setGravity(Gravity.CENTER);
        root.addView(tvStatus);

        addSpace(root, 24);

        // دکمه Accessibility
        btnAccessibility = makeButton("فعال کردن دسترسی پذیری",
                Color.parseColor("#FF6600"));
        btnAccessibility.setOnClickListener(v -> {
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
        });
        root.addView(btnAccessibility);

        addSpace(root, 12);

        // --- تنظیمات ---
        addLabel(root, "مقدار جبران Recoil (پایین)");
        sbPullDown = makeSeekBar(root, 5, 80, RecoilService.pullDown);
        tvPullDown = makeValueLabel(root, RecoilService.pullDown + " px");
        sbPullDown.setOnSeekBarChangeListener(new SeekListener() {
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                int val = v + 5;
                RecoilService.pullDown = val;
                tvPullDown.setText(val + " px");
            }
        });

        addSpace(root, 12);
        addLabel(root, "سرعت (میلی‌ثانیه)");
        sbSpeed = makeSeekBar(root, 10, 200, RecoilService.intervalMs);
        tvSpeed = makeValueLabel(root, RecoilService.intervalMs + " ms");
        sbSpeed.setOnSeekBarChangeListener(new SeekListener() {
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                int val = v + 10;
                RecoilService.intervalMs = val;
                tvSpeed.setText(val + " ms");
            }
        });

        addSpace(root, 12);
        addLabel(root, "موقعیت X دکمه شلیک");
        sbFireX = makeSeekBar(root, 100, 1980, RecoilService.fireX);
        tvFireX = makeValueLabel(root, RecoilService.fireX + "");
        sbFireX.setOnSeekBarChangeListener(new SeekListener() {
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                int val = v + 100;
                RecoilService.fireX = val;
                tvFireX.setText(val + "");
            }
        });

        addSpace(root, 12);
        addLabel(root, "موقعیت Y دکمه شلیک");
        sbFireY = makeSeekBar(root, 100, 2210, RecoilService.fireY);
        tvFireY = makeValueLabel(root, RecoilService.fireY + "");
        sbFireY.setOnSeekBarChangeListener(new SeekListener() {
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                int val = v + 100;
                RecoilService.fireY = val;
                tvFireY.setText(val + "");
            }
        });

        addSpace(root, 24);

        // دکمه start/stop
        btnToggle = makeButton("شروع AntiRecoil", Color.parseColor("#00FF88"));
        btnToggle.setTextColor(Color.BLACK);
        btnToggle.setOnClickListener(v -> toggleRecoil());
        root.addView(btnToggle);

        addSpace(root, 16);

        // راهنما
        TextView hint = new TextView(this);
        hint.setText("راهنما:\n" +
                "۱. روی 'فعال کردن دسترسی پذیری' بزن\n" +
                "۲. KAKU AntiRecoil رو پیدا کن و فعال کن\n" +
                "۳. برگرد — تنظیمات رو بذار\n" +
                "۴. بازی رو باز کن\n" +
                "۵. 'شروع AntiRecoil' بزن\n" +
                "۶. برو داخل بازی و شلیک کن");
        hint.setTextSize(13f);
        hint.setTextColor(Color.parseColor("#888888"));
        hint.setPadding(16, 16, 16, 16);
        hint.setBackgroundColor(Color.parseColor("#1A1A1A"));
        root.addView(hint);
    }

    private void toggleRecoil() {
        if (!isAccessibilityEnabled()) {
            Toast.makeText(this,
                    "اول دسترسی‌پذیری رو فعال کن!", Toast.LENGTH_LONG).show();
            return;
        }

        if (RecoilService.instance == null) {
            Toast.makeText(this, "سرویس آماده نیست", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!running) {
            RecoilService.instance.startRecoil();
            running = true;
            btnToggle.setText("متوقف کردن");
            btnToggle.setBackgroundColor(Color.parseColor("#FF4444"));
            btnToggle.setTextColor(Color.WHITE);
        } else {
            RecoilService.instance.stopRecoil();
            running = false;
            btnToggle.setText("شروع AntiRecoil");
            btnToggle.setBackgroundColor(Color.parseColor("#00FF88"));
            btnToggle.setTextColor(Color.BLACK);
        }
    }

    private boolean isAccessibilityEnabled() {
        String services = Settings.Secure.getString(
                getContentResolver(),
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        return services != null && services.contains(getPackageName());
    }

    public static void updateStatus(String msg) {
        if (tvStatus != null) {
            tvStatus.post(() -> tvStatus.setText(msg));
        }
    }

    // --- helpers ---

    private void addLabel(LinearLayout root, String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(Color.parseColor("#CCCCCC"));
        tv.setTextSize(13f);
        root.addView(tv);
    }

    private TextView makeValueLabel(LinearLayout root, String val) {
        TextView tv = new TextView(this);
        tv.setText(val);
        tv.setTextColor(Color.parseColor("#00FF88"));
        tv.setTextSize(13f);
        root.addView(tv);
        return tv;
    }

    private SeekBar makeSeekBar(LinearLayout root, int min, int max, int current) {
        SeekBar sb = new SeekBar(this);
        sb.setMax(max - min);
        sb.setProgress(current - min);
        root.addView(sb);
        return sb;
    }

    private Button makeButton(String text, int color) {
        Button btn = new Button(this);
        btn.setText(text);
        btn.setBackgroundColor(color);
        btn.setTextColor(Color.WHITE);
        btn.setTextSize(16f);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 120);
        btn.setLayoutParams(p);
        return btn;
    }

    private void addSpace(LinearLayout root, int dp) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp));
        root.addView(v);
    }

    private abstract static class SeekListener implements SeekBar.OnSeekBarChangeListener {
        public void onStartTrackingTouch(SeekBar s) {}
        public void onStopTrackingTouch(SeekBar s) {}
    }
}
