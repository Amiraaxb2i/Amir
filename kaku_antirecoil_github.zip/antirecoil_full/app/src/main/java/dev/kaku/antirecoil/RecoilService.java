package dev.kaku.antirecoil;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Intent;
import android.graphics.Path;
import android.view.accessibility.AccessibilityEvent;

public class RecoilService extends AccessibilityService {

    public static RecoilService instance = null;
    private boolean active = false;
    private Thread recoilThread = null;

    // تنظیمات پیش‌فرض
    public static int pullDown   = 20;   // مقدار کشیدن پایین (پیکسل)
    public static int fireX      = 900;  // X دکمه شلیک
    public static int fireY      = 1800; // Y دکمه شلیک
    public static int intervalMs = 50;   // سرعت (میلی‌ثانیه)

    @Override
    public void onServiceConnected() {
        instance = this;
        MainActivity.updateStatus("سرویس فعال شد");
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent e) {}

    @Override
    public void onInterrupt() {}

    @Override
    public void onDestroy() {
        super.onDestroy();
        instance = null;
        stopRecoil();
    }

    public void startRecoil() {
        if (active) return;
        active = true;
        recoilThread = new Thread(() -> {
            while (active) {
                performRecoilComp();
                try { Thread.sleep(intervalMs); } catch (InterruptedException e) { break; }
            }
        });
        recoilThread.start();
        MainActivity.updateStatus("در حال اجرا...");
    }

    public void stopRecoil() {
        active = false;
        if (recoilThread != null) {
            recoilThread.interrupt();
            recoilThread = null;
        }
        MainActivity.updateStatus("متوقف شد");
    }

    public boolean isActive() { return active; }

    private void performRecoilComp() {
        // کشیدن از fireX,fireY به fireX,fireY+pullDown
        Path path = new Path();
        path.moveTo(fireX, fireY);
        path.lineTo(fireX, fireY + pullDown);

        GestureDescription.Builder builder = new GestureDescription.Builder();
        builder.addStroke(new GestureDescription.StrokeDescription(
                path, 0, intervalMs));

        dispatchGesture(builder.build(), null, null);
    }
}
